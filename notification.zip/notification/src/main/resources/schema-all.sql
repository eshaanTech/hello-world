DROP TABLE notification_group IF EXISTS;

CREATE TABLE notification_group (
    group_id BIGINT NOT NULL ,
    group_name VARCHAR(20),
    PRIMARY KEY (group_id)
    
);
