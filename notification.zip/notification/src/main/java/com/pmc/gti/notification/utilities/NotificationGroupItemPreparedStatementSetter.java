package com.pmc.gti.notification.utilities;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.pmc.gti.notification.bo.NotificationGroup;

public class NotificationGroupItemPreparedStatementSetter implements ItemPreparedStatementSetter<NotificationGroup> {
	public void setValues(NotificationGroup result, PreparedStatement ps) throws SQLException {
        ps.setString(1, result.getGroupId());
        ps.setString(2, result.getGroupName());
       
    }

}
