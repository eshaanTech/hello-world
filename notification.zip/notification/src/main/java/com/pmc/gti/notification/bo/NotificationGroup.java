/**
 * 
 */
package com.pmc.gti.notification.bo;


/**
 * @author Evani
 *
 */
public class NotificationGroup {
	private String groupId;
	private String groupName;
	/*private Collection<String> users;*/
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	/*public Collection<String> getUsers() {
		return users;
	}
	public void setUsers(Collection<String> users) {
		this.users = users;
	}	*/

}
