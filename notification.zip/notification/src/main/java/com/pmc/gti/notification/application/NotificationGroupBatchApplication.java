/**
 * 
 */
package com.pmc.gti.notification.application;

/**
 * @author Evani
 *
 */
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@ComponentScan
@EnableAutoConfiguration
public class NotificationGroupBatchApplication {

   /* public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("notification-grp-application-context.xml");

        List<NotificationGroup> results = ctx.getBean(JdbcTemplate.class).query("SELECT group_id, group_name FROM notification_group", new RowMapper<NotificationGroup>() {
            @Override
            public NotificationGroup mapRow(ResultSet rs, int row) throws SQLException {
            	NotificationGroup notificationGroup = new NotificationGroup();
            	notificationGroup.setGroupId(rs.getLong("group_id"));
            	notificationGroup.setGroupName(rs.getString("group_name"));
                return notificationGroup;
            }
        });

        for (NotificationGroup notificationGroup : results) {
            System.out.println("Found <" + notificationGroup + "> in the database.");
        }
    }*/
    
    
    public static void main(String areg[]){
		 
    	 ApplicationContext context = new ClassPathXmlApplicationContext("notification-grp-application-context.xml");
 
        JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
        Job job = (Job) context.getBean("notificationGroupJob");
 
        try {
            JobExecution execution = jobLauncher.run(job, new JobParameters());
            System.out.println("Job Exit Status : "+ execution.getStatus());
 
        } catch (JobExecutionException e) {
            System.out.println("Job ExamResult failed");
            e.printStackTrace();
        }
    }

}