/**
 * 
 */
package com.pmc.gti.notification.processor;

import org.springframework.batch.item.ItemProcessor;

import com.pmc.gti.notification.bo.NotificationGroup;


/**
 * @author Evani
 *
 */
public class NotificationGroupProcessor implements ItemProcessor<NotificationGroup, NotificationGroup> {

	@Override
	public NotificationGroup process(final NotificationGroup notificationGroup) throws Exception {
		// TODO Auto-generated method stub
		return notificationGroup;
	}

}
